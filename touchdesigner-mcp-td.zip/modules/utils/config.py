"""
TouchDesigner MCP Web Server Configuration Module
Provides API endpoint definitions and HTTP status code settings
"""

# Enable LogLevel.DEBUG logging
DEBUG = True
